from weather.main import get_weather

if __name__ == '__main__':
    get_weather()
    