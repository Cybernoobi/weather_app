API_KEY = "3a2e88119c6da5f1b021ddcd7e05bb04"

url = "https://api.openweathermap.org/data/2.5/weather"

parameters = {
    "appid": API_KEY,
    "units": "metric",
    "lang": "ru"
}